This font is made by Typesgal and is free for both personal and commercial usage.

The font contains alternatives of capital letters and word ending characters.
Bring them to life by Character Map, or any software that supports OpenType Features.

Donations are welcome and much appreciated (typesgal@gmail.com)!

For more information you can contact here: typesgal@gmail.com