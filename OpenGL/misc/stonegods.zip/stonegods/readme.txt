Date: 10/30/2001.
Title			Stone Gods
File:             sb-stonegodstga.zip
Author:           Techx 
Email:		techx@digitalarenas.com
Website:		http://techx.digitalarenas.com

--------------------------------------------------------
This is my second skybox release. Hope you like it!
If you use this skybox please give me credit in your readme.txt, thanks. 
Feel free to drop me an Email also, I'd be interested to see your map :)

Instructions for using the Stone Gods Skybox
--------------------------------------------


1. Extract the zip at in the BASEQ3 directory.
   The zip file has all the directory structure in
   place ready for the above location.
   
2. Goto the SCRIPTS sub-directory under the BASEQ3
   directory and find the following 
   file : SHADERLIST.TXT.
   
3. Open this file up in a text editor and add the
   following line at the bottom of the file.
   
   STONEGODS
   
4. Close the file and open Q3Radiant and you should
   find on the texture menu the STONEGODS subdirectory.
   
5. Choose the STONEGODS subdirectory and you should find
   the sky texture ready for use.
   
6. If the editor displays 2 textures use the one
   called STONEGODS_SKYBOX. The other one is just so
   that you have something to remind you of what
   you are inserting into your map.
   
Special thanks to Sock @ www.planetquake.com/simland for 
shader code and instruction text.
